<html>
<!-- The variables will be here (array) and the function that pulls all the data from here will be on the javascript
    but I'll have to call it in here -->
    <head>
        <script src = "gmap.js"></script>
    </head>
    <body>
        <?php
                require_once('tweets.php');
                $tweets = array();
                $file = fopen("tweetsArray.txt","r");
                while(! feof($file)){
                    $line = fgets($file);
                    array_push($tweets, $line);
                }
        ?>
        <script>
            var tweet = <?php
                        echo json_encode($tweets);
                        ?>;
                        tweet.pop();
            var names = <?php
                        echo json_encode($accountNames); // make accountNames globa !! not sure 
                        ?>;
                        
            for(var i =0; i< tweet.length; i++){
                tweetsList.push(tweet[i]);
            }
            for(var i = 0; i <names.length; i++){
                namesList.push(names[i]); // create a (namesList in the gmap);
            }
        </script>
    </body>
</html>