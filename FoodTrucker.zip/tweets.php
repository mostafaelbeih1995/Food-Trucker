<?php
	session_start();
	require_once("TwitterAPIExchange.php");
	require_once("index.php");
		////////////////////////////////////////////////////////////////////////////////////
		$filename = $_SESSION["filename"];
			$twitterNames = array();
			$accountNames = array();
			$file = fopen($filename,"r");
			$tweets = array();

			while(! feof($file))
			 {
			  	$line = fgets($file);
			  	$tokens = explode(" ", $line);
			  	array_push($twitterNames, $tokens[0]);
			  	$tempArray = array();
			  	for($i = 1; $i< count($tokens); $i++){
			  		array_push($tempArray, $tokens[$i]);
			  	}
			  	$name = implode(" ", $tempArray);
			  	array_push($accountNames, $name);
			 }

			 fclose($file);
		/////////////////////////////////////////////////////////////////////////////////////

	$settings = array(
		"oauth_access_token" => "4228480874-SSD6AA5VLeQWml3bCd4AArAxBTnaGCPlYGDr2re",
		"oauth_access_token_secret" => "eHJcmFUW7tnV41vijlnfjMyWklZD34jWKqoFmiqCLiUFI",
		"consumer_key" => "8YvVHQg8itWHaitowJCMedGuI",
		"consumer_secret" => "Zvl93mEwPlqA1OHR8v1F5R3rPTzzSJR4Rax0Dv1wGibYtD4UJo"
	);
	$url = "https://api.twitter.com/1.1/statuses/user_timeline.json";
	$requestMethod = "GET";
	$twitter = new TwitterAPIExchange($settings);
	for($i = 0; $i < count($twitterNames); $i++){
		$getfield = "?screen_name=$twitterNames[$i]&count=1&exclude_replies=true&include_rts=false";
		$string = json_decode($twitter->setGetfield($getfield)
			->buildOauth($url, $requestMethod)
			->performRequest(),$assoc = TRUE);
		// print("<div>".$string[0]["text"]."</div>");
		array_push($tweets, $string[0]["text"]);
	}
	$file = fopen("tweetsArray.txt", "w");
			for($i =0 ; $i < count($tweets); $i++){
				$rawtxt = $tweets[$i];
				$rawtxt2 = str_replace("&amp;", "and", $rawtxt);
				$txt = str_replace("\n", " ", $rawtxt2)."\r\n";
				fwrite($file, $txt);
			}
	fclose($file);
?>