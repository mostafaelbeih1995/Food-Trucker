var map;
var tweetsList = [];
var addressList = [];
var namesList = [];

// var tweet = "Good morning we are on campus at 4400 Mass Ave NW";
// var address = generateAdress(tweet);

function generateAddress(tweet) {
    var array = tweet.split(" ");
    var tokens = ["&amp;", "And", "and", "Street", "street", "St", "st", "Avenue", "avenue", "Ave", "ave"];
    var index = -1;
    for (var i = 0; i < tokens.length; i++) {
        if (array.indexOf(tokens[i]) != -1) {
            index = array.indexOf(tokens[i]);
        }
    };
    var addressArray = [array[index - 2], array[index - 1], array[index], array[index + 1]];
    var address = addressArray.join("+");
    addressList.push(address);
}

function getCoords(address) {
    var httpreq = new XMLHttpRequest();
    httpreq.open("GET", "https://maps.googleapis.com/maps/api/geocode/json?address=" + address + "Washington+DC" + "&key=AIzaSyCkLBH7dnLbbLFj0dgoXAzC2LwMakz8nS0", false);
    httpreq.send();
    var geocode = JSON.parse(httpreq.responseText);
    // document.getElementById("map").innerHTML = "Tweets loaded: "+tweetsList.length;
    // document.getElementById("map").innerHTML = "Names loaded: "+namesList.length;
    return {lat: geocode["results"][0]["geometry"]["location"]["lat"], lng: geocode["results"][0]["geometry"]["location"]["lng"]}
};

function addMarker(address, truckName) {
    var marker = new google.maps.Marker({
        position: getCoords(address),
        icon: "marker.png",
        map: map
    });
    var addressName = address.replace(/\+/g, " ");
    var infowindow = new google.maps.InfoWindow({
        content: "<strong>"+truckName+"</strong><br>"+addressName
    });
    marker.addListener("click", function() {
        infowindow.open(map, marker);
    });
};

function initMap() {
    var mapDiv = document.getElementById("map");
    map = new google.maps.Map(mapDiv, {
        center: {lat: 38.9071923, lng: -77.03687069999999},
        zoom: 12,
        disableDefaultUI: true
    });
    // var marker = new google.maps.Marker({
    //     position: getCoords(generateAddress("Good morning we are on campus at 4400 Mass Ave NW")),
    //     map: map
    // });
    // var infowindow = new google.maps.InfoWindow({
    //     content: "<strong>American University</strong><br>"+"4400 Mass Ave NW"
    // });
    // marker.addListener("click", function() {
    //     infowindow.open(map, marker);
    // });

    for (var i = 0; i < tweetsList.length; i++) {
        generateAddress(tweetsList[i]);
    };

    for (var i = 0; i < addressList.length; i++) {
        for (var i = 0; i < namesList.length; i++) {
            addMarker(addressList[i], namesList[i]);
        }
    };
    // addMarker("Good morning we are on campus at 4400 Mass Ave NW");

};

function zoomIn() {
    map.setZoom(map.getZoom()+1);
};

function zoomOut() {
    map.setZoom(map.getZoom()-1);
};