<!DOCTYPE html>
<?php 
	session_start();
	// include tweets.php, see if we need the default, american is the only one working other than that no txt files with twitter names
	
	////
	$a = "american.txt";
	if (!isset($_SESSION["filename"])) {
		$_SESSION["filename"] = $a;
	};
	///// functions ///// 

	function italian(){ 
	    $value = "italian.txt";
	    return $value;
	} 

	function asian(){  
	    $value = "asian.txt";
	    return $value;
	} 

	function american(){ 
	    $value = "american.txt";
	    return $value;
	} 

	function indian(){ 
	    $value = "indian.txt";
	    return $value;
	} 
	function mexican(){ 
	   $value = "mexican.txt";
	    return $value;
	} 
	function defaultFunction(){
		$value = "american.txt";
	    return $value;
	}

	///// START ///// 
?>
<html>
	<head>
		<title>FoodTrucker</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>
		<script type="text/javascript" src="gmap.js"></script>
		<script type="text/javascript">
			$(window).load(function(){
				$("[data-toggle]").click(function() {
					var toggle_el = $(this).data("toggle");
					$(toggle_el).toggleClass("open-sidebar");
				});
				$(".swipe-area").swipe({
					swipeStatus:function(event, phase, direction, distance, duration, fingers) {
						if (phase=="move" && direction =="right") {
							$(".container").addClass("open-sidebar");
							return false;
						}
						if (phase=="move" && direction =="left") {
							$(".container").removeClass("open-sidebar");
						return false;
						}
					}
				});       
			});
		</script>
		<meta name="viewport" content="initial-scale=1.0">
		<meta charset="UTF-8">
	</head>

	<body>
		<?php
			require_once("linker.php");
			if (isset($_GET['run'])) $linkchoice=$_GET['run']; 
				else $linkchoice=''; 

				switch($linkchoice){ 

					case 'italian' : 
					    $a = italian(); 
					    break; 

					case 'asian' : 
					    $a = asian(); 
					    break; 

					case 'american' : 
					    $a = american(); 
					    break; 

					case 'indian' : 
					    $a = indian(); 
					    break; 

					case 'mexican' : 
					   $a =  mexican(); 
					    break; 
					default : 
					    $a = defaultFunction(); 
				}
				$_SESSION["filename"] = $a;
		?>
		<div class="container">
			<div id="sidebar">
				<ul>
					<li id="titlebar">FoodTrucker</li>
					<li><a href="?run=american">American</a></li>
					<li><a href="?run=asian">Asian</a></li>
					<li><a href="?run=indian">Indian</a></li>
					<li><a href="?run=italian">Italian</a></li>
					<li><a href="?run=mexican">Mexican</a></li>
				</ul>
			</div>

			<div class="main-content">
				<div class="swipe-area"></div>
				<a href="#" data-toggle=".container" id="sidebar-toggle">
					<span class="bar"></span>
					<span class="bar"></span>
					<span class="bar"></span>
				</a>

				<a href="#" id="sidebar-toggle1" onclick="zoomIn()"><b>+</b></a>
                <a href="#" id="sidebar-toggle2" onclick="zoomOut()"><b>–</b></a>
				
				<div id="map">
					<script src="https://maps.googleapis.com/maps/api/js?callback=initMap&key=AIzaSyCkLBH7dnLbbLFj0dgoXAzC2LwMakz8nS0" async defer></script>
				</div>
			</div>
		</div>
	</body>
</html>